import java.sql.SQLOutput;

public class Timepass3
{
    Timepass3(String y)
    {
        String nm = y;
        System.out.println("\nTIMEPASS3 ---" +  nm);
    }
}
