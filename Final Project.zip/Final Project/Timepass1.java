import java.util.*;

public class Timepass1
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your name");
        String name = sc.next();

        new Timepass2(name);

    }
}
