public class Timepass2
{
    Timepass2(String x)
    {
        String nm = x;
        System.out.println("\n\nTIMEPASS2 ---- "+x);
        new Timepass3(nm);

    }

}
